

# Get input from the user
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))


# Calculate sum
sum_result = num1 + num2

# Calculate multiplication
multiplication_result = num1 * num2

# Print the results
print(f"The sum of {num1} and {num2} is: {sum_result}")
print(f"The multiplication of {num1} and {num2} is: {multiplication_result}")