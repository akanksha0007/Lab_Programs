import math

# Get the lengths of the three sides from the user
side_a = float(input("Enter the length of side a: "))
side_b = float(input("Enter the length of side b: "))
side_c = float(input("Enter the length of side c: "))

# Check if the given sides can form a triangle
# The sum of the lengths of any two sides of a triangle must be greater than the length of the third side.
if (side_a + side_b > side_c) and \
   (side_a + side_c > side_b) and \
   (side_b + side_c > side_a):

    # Calculate the semi-perimeter
    s = (side_a + side_b + side_c) / 2

    # Calculate the area using Heron's formula
    area = math.sqrt(s * (s - side_a) * (s - side_b) * (s - side_c))

    # Print the result
    print(f"The area of the triangle is: {area:.2f}") # .2f for 2 decimal places
else:
    print("These side lengths do not form a valid triangle.")