# Get input from the user
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))

# Use a ternary operator to find the largest and print
largest = num1 if num1 > num2 else num2
print(f"The largest number is: {largest}")

# To be more specific about which variable is largest:
result = "First number is largest" if num1 > num2 else ("Second number is largest" if num2 > num1 else "Both numbers are equal")
print(result)